﻿//
// pch.h
// Header for standard system include files.
//

#pragma once

#include "mozilla\Char16.h"
#include "cocos2d.h"
#include "cocos-ext.h"


